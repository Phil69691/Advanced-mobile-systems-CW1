package com.example.daxdevelopments.utils;

public interface OnClick {
    public void clicked(int pos);
}
