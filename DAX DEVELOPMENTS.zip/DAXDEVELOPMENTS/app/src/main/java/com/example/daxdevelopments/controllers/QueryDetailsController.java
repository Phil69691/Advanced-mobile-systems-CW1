package com.example.daxdevelopments.controllers;

import android.content.Context;
import android.widget.Toast;

import androidx.navigation.NavController;

import com.example.daxdevelopments.database.DatabaseHelper;
import com.example.daxdevelopments.models.ContactModel;
import com.example.daxdevelopments.utils.HelperClass;

public class QueryDetailsController {
    private DatabaseHelper databaseHelper;
    private Context context;

    public QueryDetailsController(Context context) {
        this.context = context;
        this.databaseHelper = new DatabaseHelper(context);
    }

    public void handleUpdate(ContactModel messageModel, String adminReply, NavController navController) {
        if (HelperClass.users != null) {
            databaseHelper.deleteMessageDetails(messageModel.getId());
            Toast.makeText(context, "Deleted successfully", Toast.LENGTH_SHORT).show();
            navController.navigateUp();
        } else {
            if (adminReply.isEmpty()) {
                Toast.makeText(context, "Please enter reply first", Toast.LENGTH_SHORT).show();
                return;
            }
            messageModel.setAdminReply(adminReply);
            databaseHelper.updateMessageDetails(messageModel);
            Toast.makeText(context, "Updated successfully", Toast.LENGTH_SHORT).show();
        }
    }
}
