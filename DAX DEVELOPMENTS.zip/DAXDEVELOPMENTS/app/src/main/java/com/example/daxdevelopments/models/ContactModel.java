package com.example.daxdevelopments.models;

import java.io.Serializable;

public class ContactModel implements Serializable {
    int id, userId;
    String image, name, phone, email, message, adminReply;

    public ContactModel() {
    }

    public ContactModel(int userId, String image, String name, String phone, String email, String message, String adminReply) {
        this.userId = userId;
        this.image = image;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.message = message;
        this.adminReply = adminReply;
    }

    public ContactModel(int id, int userId, String image, String name, String phone, String email, String message, String adminReply) {
        this.id = id;
        this.userId = userId;
        this.image = image;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.message = message;
        this.adminReply = adminReply;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getAdminReply() {
        return adminReply;
    }

    public void setAdminReply(String adminReply) {
        this.adminReply = adminReply;
    }
}
