package com.example.daxdevelopments.views.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import com.example.daxdevelopments.controllers.PortfolioController;
import com.example.daxdevelopments.databinding.FragmentPortfolioBinding;
import com.example.daxdevelopments.utils.OnClick;
import com.example.daxdevelopments.views.adapters.PortfolioAdapter;

public class PortfolioFragment extends Fragment {
    private FragmentPortfolioBinding binding;
    private PortfolioController portfolioController;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentPortfolioBinding.inflate(inflater, container, false);
        portfolioController = new PortfolioController();
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.rvPortfolio.setLayoutManager(new GridLayoutManager(requireContext(), 3));
        PortfolioAdapter portfolioAdapter = new PortfolioAdapter(
                portfolioController.getImageList(), requireContext(), new OnClick() {
            @Override
            public void clicked(int pos) {
                portfolioController.setCurrentPosition(pos);
                portfolioController.showImagesDialog(requireContext());
            }
        });

        binding.rvPortfolio.setAdapter(portfolioAdapter);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
