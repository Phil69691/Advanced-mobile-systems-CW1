package com.example.daxdevelopments.controllers;

import android.content.Context;
import android.net.Uri;
import android.util.Patterns;
import android.widget.Toast;

import com.example.daxdevelopments.database.DatabaseHelper;
import com.example.daxdevelopments.models.ContactModel;
import com.example.daxdevelopments.utils.HelperClass;

public class ContactUsController {
    private Context context;
    private DatabaseHelper databaseHelper;

    public ContactUsController(Context context) {
        this.context = context;
        this.databaseHelper = new DatabaseHelper(context);
    }

    public boolean validateContactDetails(String name, String phone, String email, String message) {
        if (name.isEmpty()) {
            showMessage("Please enter name");
            return false;
        }
        if (phone.isEmpty()) {
            showMessage("Please enter phone");
            return false;
        }
        if (email.isEmpty()) {
            showMessage("Please enter email");
            return false;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showMessage("Please enter email in correct format");
            return false;
        }
        if (message.isEmpty()) {
            showMessage("Please enter message");
            return false;
        }
        return true;
    }

    public void sendMessage(String name, String phone, String email, String message, String imageUri) {
        ContactModel contactModel = new ContactModel(
                HelperClass.users.getId(), imageUri, name, phone, email, message, "");
        databaseHelper.addMessageDetails(contactModel);
        showMessage("Message sent successfully");
    }

    private void showMessage(String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }
}
