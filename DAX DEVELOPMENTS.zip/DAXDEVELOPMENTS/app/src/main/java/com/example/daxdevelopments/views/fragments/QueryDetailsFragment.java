package com.example.daxdevelopments.views.fragments;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.example.daxdevelopments.R;
import com.example.daxdevelopments.controllers.QueryDetailsController;
import com.example.daxdevelopments.databinding.FragmentQueryDetailsBinding;
import com.example.daxdevelopments.models.ContactModel;
import com.example.daxdevelopments.utils.HelperClass;

public class QueryDetailsFragment extends Fragment {
    private FragmentQueryDetailsBinding binding;
    private ContactModel messageModel;
    private QueryDetailsController queryDetailsController;

    public QueryDetailsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            messageModel = (ContactModel) getArguments().getSerializable("message");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentQueryDetailsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        queryDetailsController = new QueryDetailsController(requireContext());
        setupUI();
    }

    private void setupUI() {
        if (messageModel != null) {
            setupAdminReplyView();
            loadImage();
            displayMessageDetails();

            binding.ivBack.setOnClickListener(v -> Navigation.findNavController(v).navigateUp());

            binding.btnUpdate.setOnClickListener(v -> {
                String adminReply = binding.etAdminReply.getText().toString();
                queryDetailsController.handleUpdate(messageModel, adminReply, Navigation.findNavController(v));
            });
        }
    }

    private void setupAdminReplyView() {
        if (HelperClass.users != null) {
            binding.tvAdminReply.setVisibility(View.VISIBLE);
            binding.tvAdminReplyLabel.setVisibility(View.GONE);
            binding.etAdminReply.setVisibility(View.GONE);
            binding.btnUpdate.setText("Delete");
        } else {
            binding.tvAdminReply.setVisibility(View.GONE);
            binding.tvAdminReplyLabel.setVisibility(View.VISIBLE);
            binding.etAdminReply.setVisibility(View.VISIBLE);
            binding.btnUpdate.setText("Update");
        }
    }

    private void loadImage() {
        if (!messageModel.getImage().isEmpty()) {
            Glide.with(requireContext())
                    .asBitmap()
                    .load(Uri.parse(messageModel.getImage()))
                    .into(new CustomTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                            binding.ivImage.setImageBitmap(resource);
                        }

                        @Override
                        public void onLoadCleared(@Nullable Drawable placeholder) {
                            binding.ivImage.setImageResource(R.drawable.no_image);
                            Log.d("CheckError", "onLoadCleared: " + placeholder);
                        }
                    });
        }
    }

    private void displayMessageDetails() {
        binding.tvName.setText(messageModel.getName());
        binding.tvPhone.setText(messageModel.getPhone());
        binding.tvEmail.setText(messageModel.getEmail());
        binding.tvMessage.setText(messageModel.getMessage());

        if (messageModel.getAdminReply().isEmpty()) {
            binding.tvAdminReply.setText("Admin Reply: N/A yet");
        } else {
            binding.tvAdminReply.setText("Admin Reply: " + messageModel.getAdminReply());
        }
        binding.etAdminReply.setText(messageModel.getAdminReply());
    }
}
