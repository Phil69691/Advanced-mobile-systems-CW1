package com.example.daxdevelopments.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.daxdevelopments.models.UserModel;
import com.example.daxdevelopments.models.ContactModel;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "dax_developments.db";

    // Users table
    private static final String TABLE_USERS = "users_table";
    private static final String KEY_ID_USER = "user_id";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD = "password";

    // Contact details table
    private static final String TABLE_CONTACTS = "contact_details";
    private static final String KEY_ID_CONTACT = "contact_id";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_IMAGE = "image";
    private static final String KEY_NAME = "name";
    private static final String KEY_PHONE = "phone";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_MESSAGE = "message";
    private static final String KEY_ADMIN_REPLY = "admin_reply";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the Users table
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + " ("
                + KEY_ID_USER + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + KEY_USERNAME + " TEXT NOT NULL, "
                + KEY_PASSWORD + " TEXT NOT NULL"
                + ");";
        db.execSQL(CREATE_USERS_TABLE);

        // Create the Contact Details table
        String CREATE_CONTACTS_TABLE = "CREATE TABLE " + TABLE_CONTACTS + " ("
                + KEY_ID_CONTACT + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + KEY_USER_ID + " INTEGER, "
                + KEY_IMAGE + " TEXT, "
                + KEY_NAME + " TEXT NOT NULL, "
                + KEY_PHONE + " TEXT NOT NULL, "
                + KEY_EMAIL + " TEXT NOT NULL, "
                + KEY_MESSAGE + " TEXT NOT NULL, "
                + KEY_ADMIN_REPLY + " TEXT, "
                + "FOREIGN KEY (" + KEY_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + KEY_ID_USER + ") ON DELETE CASCADE"
                + ");";
        db.execSQL(CREATE_CONTACTS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CONTACTS);
        onCreate(db);
    }

    public void register(UserModel user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_USERNAME, user.getUsername());
        values.put(KEY_PASSWORD, user.getPassword());
        db.insert(TABLE_USERS, null, values);
        db.close();
    }

    public UserModel getUserDetails(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        UserModel user = null;

        String query = "SELECT * FROM " + TABLE_USERS + " WHERE " + KEY_USERNAME + " = ? AND " + KEY_PASSWORD + " = ?";
        try (Cursor cursor = db.rawQuery(query, new String[]{username, password})) {
            if (cursor.moveToFirst()) {
                user = new UserModel();
                user.setId(cursor.getInt(cursor.getColumnIndexOrThrow(KEY_ID_USER)));
                user.setUsername(cursor.getString(cursor.getColumnIndexOrThrow(KEY_USERNAME)));
                user.setPassword(cursor.getString(cursor.getColumnIndexOrThrow(KEY_PASSWORD)));
            }
        }
        return user;
    }

    public boolean isUsernameAlreadyExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        boolean exists = false;

        String query = "SELECT 1 FROM " + TABLE_USERS + " WHERE " + KEY_USERNAME + " = ?";
        try (Cursor cursor = db.rawQuery(query, new String[]{username})) {
            exists = cursor.moveToFirst();
        }
        return exists;
    }

    // Add a new contact message
    public void addMessageDetails(ContactModel contact) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(KEY_USER_ID, contact.getUserId());
        values.put(KEY_IMAGE, contact.getImage());
        values.put(KEY_NAME, contact.getName());
        values.put(KEY_PHONE, contact.getPhone());
        values.put(KEY_EMAIL, contact.getEmail());
        values.put(KEY_MESSAGE, contact.getMessage());
        values.put(KEY_ADMIN_REPLY, contact.getAdminReply());

        db.insert(TABLE_CONTACTS, null, values);
        db.close();
    }

    // Get all contact messages
    public List<ContactModel> getAllMessageDetails() {
        List<ContactModel> contacts = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_CONTACTS;

        try (Cursor cursor = db.rawQuery(query, null)) {
            while (cursor.moveToNext()) {
                ContactModel contact = new ContactModel();
                contact.setId(cursor.getInt(cursor.getColumnIndexOrThrow(KEY_ID_CONTACT)));
                contact.setUserId(cursor.getInt(cursor.getColumnIndexOrThrow(KEY_USER_ID)));
                contact.setImage(cursor.getString(cursor.getColumnIndexOrThrow(KEY_IMAGE)));
                contact.setName(cursor.getString(cursor.getColumnIndexOrThrow(KEY_NAME)));
                contact.setPhone(cursor.getString(cursor.getColumnIndexOrThrow(KEY_PHONE)));
                contact.setEmail(cursor.getString(cursor.getColumnIndexOrThrow(KEY_EMAIL)));
                contact.setMessage(cursor.getString(cursor.getColumnIndexOrThrow(KEY_MESSAGE)));
                contact.setAdminReply(cursor.getString(cursor.getColumnIndexOrThrow(KEY_ADMIN_REPLY)));
                contacts.add(contact);
            }
        }
        return contacts;
    }

    // Get all contact messages for a specific user
    public List<ContactModel> getAllMessageDetailsByUserId(int userId) {
        List<ContactModel> contacts = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_CONTACTS + " WHERE " + KEY_USER_ID + " = ?";

        try (Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(userId)})) {
            while (cursor.moveToNext()) {
                ContactModel contact = new ContactModel();
                contact.setId(cursor.getInt(cursor.getColumnIndexOrThrow(KEY_ID_CONTACT)));
                contact.setUserId(cursor.getInt(cursor.getColumnIndexOrThrow(KEY_USER_ID)));
                contact.setImage(cursor.getString(cursor.getColumnIndexOrThrow(KEY_IMAGE)));
                contact.setName(cursor.getString(cursor.getColumnIndexOrThrow(KEY_NAME)));
                contact.setPhone(cursor.getString(cursor.getColumnIndexOrThrow(KEY_PHONE)));
                contact.setEmail(cursor.getString(cursor.getColumnIndexOrThrow(KEY_EMAIL)));
                contact.setMessage(cursor.getString(cursor.getColumnIndexOrThrow(KEY_MESSAGE)));
                contact.setAdminReply(cursor.getString(cursor.getColumnIndexOrThrow(KEY_ADMIN_REPLY)));
                contacts.add(contact);
            }
        }
        return contacts;
    }

    // Update contact details
    public void updateMessageDetails(ContactModel contact) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(KEY_USER_ID, contact.getUserId());
        values.put(KEY_IMAGE, contact.getImage());
        values.put(KEY_NAME, contact.getName());
        values.put(KEY_PHONE, contact.getPhone());
        values.put(KEY_EMAIL, contact.getEmail());
        values.put(KEY_MESSAGE, contact.getMessage());
        values.put(KEY_ADMIN_REPLY, contact.getAdminReply());

        db.update(TABLE_CONTACTS, values, KEY_ID_CONTACT + " = ?", new String[]{String.valueOf(contact.getId())});
        db.close();
    }

    // Delete a contact message
    public void deleteMessageDetails(int contactId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CONTACTS, KEY_ID_CONTACT + " = ?", new String[]{String.valueOf(contactId)});
        db.close();
    }
}
