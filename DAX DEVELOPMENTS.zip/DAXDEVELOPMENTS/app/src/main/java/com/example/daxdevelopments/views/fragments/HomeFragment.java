package com.example.daxdevelopments.views.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import com.example.daxdevelopments.controllers.HomeController;
import com.example.daxdevelopments.databinding.FragmentHomeBinding;
import com.example.daxdevelopments.views.adapters.HomeViewPagerAdapter;

public class HomeFragment extends Fragment {
    private FragmentHomeBinding binding;
    private HomeController homeController;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        homeController = new HomeController();
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        HomeViewPagerAdapter adapter = new HomeViewPagerAdapter(requireContext(), homeController.getImageList());
        binding.viewPager.setAdapter(adapter);
        binding.viewPager.setPageTransformer(new HomeController.FadePageTransformer());

        homeController.getCurrentPageLiveData().observe(getViewLifecycleOwner(), new Observer<Integer>() {
            @Override
            public void onChanged(Integer position) {
                binding.viewPager.setCurrentItem(position, true);
            }
        });

        homeController.startAutoSlide();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        homeController.stopAutoSlide();
        binding = null;
    }
}
