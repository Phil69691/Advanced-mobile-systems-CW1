package com.example.daxdevelopments.controllers;

import android.os.Handler;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.viewpager2.widget.ViewPager2;
import com.example.daxdevelopments.R;
import java.util.Arrays;
import java.util.List;

public class HomeController {
    private final List<Integer> imageList = Arrays.asList(
            R.drawable.vp1,
            R.drawable.vp2,
            R.drawable.vp3
    );

    private final Handler handler = new Handler();
    private int currentPage = 0;
    private final MutableLiveData<Integer> currentPageLiveData = new MutableLiveData<>(0);

    private final Runnable runnable = new Runnable() {
        @Override
        public void run() {
            if (currentPage >= imageList.size()) {
                currentPage = 0;
            }
            currentPageLiveData.postValue(currentPage++);
            handler.postDelayed(this, 1500);
        }
    };

    public void startAutoSlide() {
        handler.postDelayed(runnable, 1500);
    }

    public void stopAutoSlide() {
        handler.removeCallbacks(runnable);
    }

    public List<Integer> getImageList() {
        return imageList;
    }

    public LiveData<Integer> getCurrentPageLiveData() {
        return currentPageLiveData;
    }

    public static class FadePageTransformer implements ViewPager2.PageTransformer {
        @Override
        public void transformPage(@NonNull View page, float position) {
            page.setAlpha(1 - Math.abs(position));
            page.setTranslationX(-position * page.getWidth());
        }
    }
}
