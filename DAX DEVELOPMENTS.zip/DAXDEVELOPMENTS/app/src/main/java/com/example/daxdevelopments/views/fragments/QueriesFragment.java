package com.example.daxdevelopments.views.fragments;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.daxdevelopments.controllers.QueriesController;
import com.example.daxdevelopments.views.activities.AuthActivity;
import com.example.daxdevelopments.views.adapters.QueriesAdapter;
import com.example.daxdevelopments.databinding.FragmentQueriesBinding;
import com.example.daxdevelopments.models.ContactModel;

import java.util.ArrayList;

public class QueriesFragment extends Fragment {
    private FragmentQueriesBinding binding;
    private QueriesController queriesController;
    private ArrayList<ContactModel> messagesList = new ArrayList<>();

    public QueriesFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentQueriesBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        queriesController = new QueriesController(requireContext());
        setupRecyclerView();
        binding.ivLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(requireActivity(), AuthActivity.class));
                requireActivity().finishAffinity();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        loadMessages();
    }

    private void setupRecyclerView() {
        binding.rvMessages.setLayoutManager(new LinearLayoutManager(requireContext()));
    }

    private void loadMessages() {
        messagesList.clear();
        messagesList.addAll(queriesController.getMessagesList());
        QueriesAdapter queriesAdapter = new QueriesAdapter(messagesList, requireContext());
        binding.rvMessages.setAdapter(queriesAdapter);
    }
}
