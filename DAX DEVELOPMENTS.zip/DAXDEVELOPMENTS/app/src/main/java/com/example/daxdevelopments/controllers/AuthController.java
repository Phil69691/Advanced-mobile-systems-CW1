package com.example.daxdevelopments.controllers;

import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import com.example.daxdevelopments.database.DatabaseHelper;
import com.example.daxdevelopments.models.UserModel;
import com.example.daxdevelopments.utils.HelperClass;
import com.example.daxdevelopments.views.activities.AuthActivity;
import com.example.daxdevelopments.views.activities.MainActivity;

public class AuthController {
    private Context context;
    private DatabaseHelper databaseHelper;

    public AuthController(Context context) {
        this.context = context;
        this.databaseHelper = new DatabaseHelper(context);
    }

    public boolean validateCredentials(String username, String password) {
        if (username.isEmpty()) {
            showMessage("Please enter username");
            return false;
        }
        if (password.isEmpty()) {
            showMessage("Please enter password");
            return false;
        }
        return true;
    }

    public void login(String username, String password) {
        if (username.equals("admin") && password.equals("admin@123")) {
            HelperClass.users = null;
            navigateToMain();
        } else {
            UserModel userModel = databaseHelper.getUserDetails(username, password);
            if (userModel != null) {
                HelperClass.users = userModel;
                navigateToMain();
            } else {
                showMessage("Wrong username or password, Please try again");
            }
        }
    }

    public void register(String username, String password) {
        if (!databaseHelper.isUsernameAlreadyExists(username)) {
            UserModel userModel = new UserModel(username, password);
            databaseHelper.register(userModel);
            UserModel getUserDetails = databaseHelper.getUserDetails(username, password);
            if (getUserDetails != null) {
                showMessage("Registered Successfully");
                HelperClass.users = getUserDetails;
                navigateToMain();
            }
        } else {
            showMessage("Username already exists, Please try again");
        }
    }

    private void navigateToMain() {
        context.startActivity(new Intent(context, MainActivity.class));
        if (context instanceof AuthActivity) {
            ((AuthActivity) context).finishAffinity();
        }
    }

    private void showMessage(String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }
}
