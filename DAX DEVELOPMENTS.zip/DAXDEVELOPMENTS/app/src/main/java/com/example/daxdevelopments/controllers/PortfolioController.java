package com.example.daxdevelopments.controllers;

import android.app.Dialog;
import android.content.Context;
import android.widget.ImageView;
import androidx.cardview.widget.CardView;
import com.example.daxdevelopments.R;
import java.util.Arrays;
import java.util.List;

public class PortfolioController {
    private final List<Integer> imageList = Arrays.asList(
            R.drawable.portfolio1, R.drawable.portfolio2, R.drawable.portfolio3,
            R.drawable.portfolio4, R.drawable.portfolio5, R.drawable.portfolio6,
            R.drawable.portfolio7, R.drawable.portfolio8, R.drawable.portfolio9,
            R.drawable.portfolio10, R.drawable.portfolio11, R.drawable.portfolio12,
            R.drawable.portfolio13, R.drawable.portfolio14, R.drawable.portfolio15,
            R.drawable.portfolio16, R.drawable.portfolio17, R.drawable.portfolio18,
            R.drawable.portfolio19, R.drawable.portfolio20, R.drawable.portfolio21
    );

    private int currentPosition = 0;

    public List<Integer> getImageList() {
        return imageList;
    }

    public void setCurrentPosition(int position) {
        currentPosition = position;
    }

    public void showImagesDialog(Context context) {
        Dialog dialog = new Dialog(context, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        dialog.setContentView(R.layout.item_portfolio_dialog);

        ImageView ivClose = dialog.findViewById(R.id.ivClose);
        ImageView ivPortfolio = dialog.findViewById(R.id.ivPortfolio);
        CardView cvForward = dialog.findViewById(R.id.cvForward);
        CardView cvBackward = dialog.findViewById(R.id.cvBackward);

        ivPortfolio.setImageResource(imageList.get(currentPosition));

        ivClose.setOnClickListener(v -> dialog.dismiss());

        cvForward.setOnClickListener(v -> {
            if (currentPosition < imageList.size() - 1) {
                currentPosition++;
                ivPortfolio.setImageResource(imageList.get(currentPosition));
            }
        });

        cvBackward.setOnClickListener(v -> {
            if (currentPosition > 0) {
                currentPosition--;
                ivPortfolio.setImageResource(imageList.get(currentPosition));
            }
        });

        dialog.show();
    }
}
