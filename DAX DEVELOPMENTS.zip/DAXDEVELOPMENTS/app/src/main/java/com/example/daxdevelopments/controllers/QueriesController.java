package com.example.daxdevelopments.controllers;

import android.content.Context;

import com.example.daxdevelopments.database.DatabaseHelper;
import com.example.daxdevelopments.models.ContactModel;
import com.example.daxdevelopments.utils.HelperClass;

import java.util.ArrayList;

public class QueriesController {
    private DatabaseHelper databaseHelper;

    public QueriesController(Context context) {
        this.databaseHelper = new DatabaseHelper(context);
    }

    public ArrayList<ContactModel> getMessagesList() {
        if (HelperClass.users != null) {
            return (ArrayList<ContactModel>) databaseHelper.getAllMessageDetailsByUserId(HelperClass.users.getId());
        } else {
            return (ArrayList<ContactModel>) databaseHelper.getAllMessageDetails();
        }
    }
}
