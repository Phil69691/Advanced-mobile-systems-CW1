package com.example.daxdevelopments.utils;

import com.example.daxdevelopments.models.UserModel;

public class HelperClass {
    public static UserModel users;
}
