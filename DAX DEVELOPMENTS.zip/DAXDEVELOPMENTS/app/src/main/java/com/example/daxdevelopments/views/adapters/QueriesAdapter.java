package com.example.daxdevelopments.views.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.example.daxdevelopments.R;
import com.example.daxdevelopments.models.ContactModel;

import java.util.List;

public class QueriesAdapter extends RecyclerView.Adapter<QueriesAdapter.ViewHolder> {
    List<ContactModel> messagesList;
    Context context;

    public QueriesAdapter(List<ContactModel> messagesList, Context context) {
        this.messagesList = messagesList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_messages, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        ContactModel message  = messagesList.get(position);
        if (!message.getImage().isEmpty()){
            Glide.with(context)
                    .asBitmap()
                    .load(Uri.parse(message.getImage()))
                    .into(new CustomTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                            holder.ivImage.setImageBitmap(resource);
                        }

                        @Override
                        public void onLoadCleared(@Nullable Drawable placeholder) {
                            holder.ivImage.setImageResource(R.drawable.no_image);
                            Log.d("CheckError", "onLoadCleared: "+placeholder);
                        }
                    });
        }
        holder.tvMessage.setText(message.getMessage());
        if (message.getAdminReply().equals("")){
            holder.tvStatus.setText("Pending");
            holder.tvStatus.setTextColor(context.getResources().getColor(R.color.pending));
        }else{
            holder.tvStatus.setText("Replied");
            holder.tvStatus.setTextColor(context.getResources().getColor(R.color.replied));
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putSerializable("message", message);
                Navigation.findNavController(view).navigate(R.id.action_navigation_queries_to_navigation_query_details, bundle);
            }
        });
    }

    @Override
    public int getItemCount() {
        return messagesList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivImage;
        TextView tvMessage, tvStatus;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivImage = itemView.findViewById(R.id.ivImage);
            tvMessage = itemView.findViewById(R.id.tvMessage);
            tvStatus = itemView.findViewById(R.id.tvStatus);
        }
    }
}
