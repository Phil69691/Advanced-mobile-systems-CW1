package com.example.daxdevelopments.controllers;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.Locale;

public class MapController implements OnMapReadyCallback {
    private final Activity activity;
    private GoogleMap googleMap;
    private final FusedLocationProviderClient fusedLocationClient;
    private LatLng officeLatLng = new LatLng(51.52937803761513, -0.7569507600657072);
    private LatLng userLatLng;

    public MapController(Activity activity) {
        this.activity = activity;
        this.fusedLocationClient = LocationServices.getFusedLocationProviderClient(activity);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap map) {
        this.googleMap = map;
        setupMap();
        fetchUserLocation();
    }

    private void setupMap() {
        googleMap.addMarker(new MarkerOptions()
                .position(officeLatLng)
                .title("Office Location"));
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(officeLatLng, 15));

        if (checkLocationPermission()) {
            googleMap.setMyLocationEnabled(true);
        } else {
            requestLocationPermission();
        }

        googleMap.setOnMarkerClickListener(marker -> {
            if (userLatLng != null) {
                openDirectionsInGoogleMaps(userLatLng, officeLatLng);
            } else {
                Toast.makeText(activity, "Current location not available", Toast.LENGTH_SHORT).show();
            }
            return true;
        });
    }

    private boolean checkLocationPermission() {
        return ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(activity, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestLocationPermission() {
        ActivityCompat.requestPermissions(activity,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
    }

    private void fetchUserLocation() {
        if (!checkLocationPermission()) {
            return;
        }

        fusedLocationClient.getLastLocation().addOnSuccessListener(activity, location -> {
            if (location != null) {
                userLatLng = new LatLng(location.getLatitude(), location.getLongitude());
            } else {
                Toast.makeText(activity, "Unable to fetch current location", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void openDirectionsInGoogleMaps(LatLng start, LatLng destination) {
        String uri = String.format(Locale.ENGLISH,
                "https://www.google.com/maps/dir/?api=1&origin=%f,%f&destination=%f,%f&travelmode=driving",
                start.latitude, start.longitude, destination.latitude, destination.longitude);
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
        intent.setPackage("com.google.android.apps.maps");
        activity.startActivity(intent);
    }
}
